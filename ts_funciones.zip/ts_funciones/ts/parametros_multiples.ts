/* Observa que iteramos sobbre el elemento 0 de la 
"matriz" que es el que, realmente, contiene la matriz 
de elementos. 
Si omites los tres puntos en el nombre del parámetro al declarar la función, deberás iterar directamente sobre la matriz. 
Es decir, si la función la declaras como:
function multiples(color:string, banderas:string[])
el bucle que la itera lo declararemos como:
for (let bandera of banderas)
*/
function multiples(color:string, ...banderas:string[])
{
    let lista:string = `
        <p>El color ${color} aparece, entre otras, 
        en las siguientes banderas:</p>
        <ul>
    `;
    for (let bandera of banderas[0])
    {
        lista += `
            <li>${bandera}</li>
        `;
    }
    lista += '</ul>';
    document.getElementById("main_content").innerHTML = lista;
}

let banderas:string[] = [
    "Portugal",
    "Brasil", 
    "Italia"
];

let color:string = "verde";
multiples(color, banderas);
