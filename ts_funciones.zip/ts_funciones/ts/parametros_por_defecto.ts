function saludo(nombre:string = "Anónimo")
{
    document.getElementById("parrafo_de_saludo").innerHTML = `<h1>${nombre}</h1>`;
}