window.onload = function(){
  document.getElementById("saludo").innerHTML = `
    <h1>Hola desde la función anónima.</h1>
  `;
}