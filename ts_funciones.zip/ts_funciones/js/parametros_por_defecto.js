"use strict";
function saludo(nombre = "Anónimo") {
    document.getElementById("parrafo_de_saludo").innerHTML = `<h1>${nombre}</h1>`;
}
