"use strict";
function opcional(parametro) {
    console.log(parametro);
    let resultado = (parametro == undefined) ? "<h1>No se ha pasado el parámetro</h1>" : `<h1>El argumento vale "${parametro}".</h1>`;
    document.getElementById("parrafo_de_saludo").innerHTML = resultado;
}
