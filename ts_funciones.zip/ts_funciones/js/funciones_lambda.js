"use strict";
lambda_operacion = (lambda_operador) => {
    let resultado;
    let operando_1 = parseInt(document.getElementById("operando_1").value);
    let operando_2 = parseInt(document.getElementById("operando_2").value);
    switch (lambda_operador) {
        case "+":
            resultado = operando_1 + operando_2;
            break;
        case "-":
            resultado = operando_1 - operando_2;
            break;
        case "*":
            resultado = operando_1 * operando_2;
            break;
        case "/":
            if (operando_2 === 0) {
                resultado = "No se puede hacer";
                break;
            }
            resultado = operando_1 / operando_2;
            break;
        case "%":
            if (operando_2 === 0) {
                resultado = "No se puede hacer";
                break;
            }
            resultado = operando_1 % operando_2;
            break;
        default:
            resultado = "";
    }
    document.getElementById("resultado").value = resultado;
};
